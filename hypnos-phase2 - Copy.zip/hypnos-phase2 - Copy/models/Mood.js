const mongoose = require('mongoose');

const moodSchema = new mongoose.Schema({
    userId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true
    },
    mood: {
        type: String,
        required: true,
        enum: ['Excellent', 'Good', 'Okay', 'Down', 'Struggling']
    },
    moodScore: {
        type: Number,
        required: true,
        min: 1,
        max: 5
    },
    date: {
        type: Date,
        default: Date.now
    },
    notes: {
        type: String,
        default: ''
    },
    screenTime: {
        type: Number, // in minutes, for correlation
        default: 0
    }
}, {
    timestamps: true
});

// Index for faster queries
moodSchema.index({ userId: 1, date: -1 });

// Ensure one mood entry per user per day
moodSchema.index({ userId: 1, date: 1 }, { unique: false });

module.exports = mongoose.model('Mood', moodSchema);
