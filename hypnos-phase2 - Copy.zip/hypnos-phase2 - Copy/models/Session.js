const mongoose = require('mongoose');

const sessionSchema = new mongoose.Schema({
    userId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true
    },
    category: {
        type: String,
        required: true,
        enum: ['Social Media', 'Work', 'Gaming', 'Movies', 'Study', 'Other']
    },
    duration: {
        type: Number, // in minutes
        required: true,
        min: 0
    },
    date: {
        type: Date,
        default: Date.now
    },
    notes: {
        type: String,
        default: ''
    }
}, {
    timestamps: true
});

// Index for faster queries
sessionSchema.index({ userId: 1, date: -1 });

module.exports = mongoose.model('Session', sessionSchema);
