const express = require('express');
const router = express.Router();
const Goal = require('../models/Goal');
const User = require('../models/User');

// GET - Goals page
router.get('/', async (req, res) => {
    try {
        const userId = req.query.userId;
        
        if (!userId) {
            return res.redirect('/');
        }
        
        const user = await User.findById(userId);
        const search = req.query.search || '';
        
        // Build query
        let query = { userId };
        if (search) {
            query.$or = [
                { name: { $regex: search, $options: 'i' } },
                { category: { $regex: search, $options: 'i' } },
                { description: { $regex: search, $options: 'i' } }
            ];
        }
        
        const activeGoals = await Goal.find({ ...query, isCompleted: false })
            .sort({ createdAt: -1 });
        
        const completedGoals = await Goal.find({ ...query, isCompleted: true })
            .sort({ completedDate: -1 });
        
        res.render('goals', {
            title: 'Goals - Hypnos',
            user,
            activeGoals,
            completedGoals,
            search
        });
    } catch (error) {
        console.error('Goals page error:', error);
        res.status(500).send('Error loading goals');
    }
});

// POST - Create new goal
router.post('/', async (req, res) => {
    try {
        const { userId, name, category, description, targetTime } = req.body;
        
        const goal = new Goal({
            userId,
            name,
            category,
            description: description || '',
            targetTime: parseInt(targetTime)
        });
        
        await goal.save();
        res.redirect(`/goals?userId=${userId}`);
    } catch (error) {
        console.error('Create goal error:', error);
        res.status(500).send('Error creating goal');
    }
});

// GET - Edit goal page
router.get('/:id/edit', async (req, res) => {
    try {
        const userId = req.query.userId;
        const goal = await Goal.findById(req.params.id);
        const user = await User.findById(userId);
        
        if (!goal) {
            return res.redirect(`/goals?userId=${userId}`);
        }
        
        res.render('goals-edit', {
            title: 'Edit Goal - Hypnos',
            user,
            goal
        });
    } catch (error) {
        console.error('Edit goal page error:', error);
        res.status(500).send('Error loading edit page');
    }
});

// PUT - Update goal
router.put('/:id', async (req, res) => {
    try {
        const { userId, name, category, description, targetTime } = req.body;
        
        await Goal.findByIdAndUpdate(req.params.id, {
            name,
            category,
            description: description || '',
            targetTime: parseInt(targetTime)
        });
        
        res.redirect(`/goals?userId=${userId}`);
    } catch (error) {
        console.error('Update goal error:', error);
        res.status(500).send('Error updating goal');
    }
});

// POST - Toggle goal completion
router.post('/:id/toggle', async (req, res) => {
    try {
        const userId = req.body.userId;
        const goal = await Goal.findById(req.params.id);
        
        if (goal) {
            goal.isCompleted = !goal.isCompleted;
            goal.status = goal.isCompleted ? 'completed' : 'active';
            goal.completedDate = goal.isCompleted ? new Date() : null;
            await goal.save();
        }
        
        res.redirect(`/goals?userId=${userId}`);
    } catch (error) {
        console.error('Toggle goal error:', error);
        res.status(500).send('Error toggling goal');
    }
});

// DELETE - Delete goal
router.delete('/:id', async (req, res) => {
    try {
        const userId = req.query.userId || req.body.userId;
        await Goal.findByIdAndDelete(req.params.id);
        res.redirect(`/goals?userId=${userId}`);
    } catch (error) {
        console.error('Delete goal error:', error);
        res.status(500).send('Error deleting goal');
    }
});

module.exports = router;
