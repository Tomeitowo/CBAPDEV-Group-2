const express = require('express');
const router = express.Router();
const Session = require('../models/Session');
const User = require('../models/User');

// GET - Sessions page
router.get('/', async (req, res) => {
    try {
        const userId = req.query.userId;
        
        if (!userId) {
            return res.redirect('/');
        }
        
        const user = await User.findById(userId);
        const search = req.query.search || '';
        
        // Build query
        let query = { userId };
        if (search) {
            query.$or = [
                { category: { $regex: search, $options: 'i' } },
                { notes: { $regex: search, $options: 'i' } }
            ];
        }
        
        const sessions = await Session.find(query)
            .sort({ date: -1 })
            .limit(50);
        
        res.render('sessions', {
            title: 'Sessions - Hypnos',
            user,
            sessions,
            search
        });
    } catch (error) {
        console.error('Sessions page error:', error);
        res.status(500).send('Error loading sessions');
    }
});

// POST - Create new session
router.post('/', async (req, res) => {
    try {
        const { userId, category, duration, notes, date } = req.body;
        
        const session = new Session({
            userId,
            category,
            duration: parseInt(duration),
            notes: notes || '',
            date: date ? new Date(date) : new Date()
        });
        
        await session.save();
        res.redirect(`/sessions?userId=${userId}`);
    } catch (error) {
        console.error('Create session error:', error);
        res.status(500).send('Error creating session');
    }
});

// GET - Edit session page
router.get('/:id/edit', async (req, res) => {
    try {
        const userId = req.query.userId;
        const session = await Session.findById(req.params.id);
        const user = await User.findById(userId);
        
        if (!session) {
            return res.redirect(`/sessions?userId=${userId}`);
        }
        
        res.render('sessions-edit', {
            title: 'Edit Session - Hypnos',
            user,
            session
        });
    } catch (error) {
        console.error('Edit session page error:', error);
        res.status(500).send('Error loading edit page');
    }
});

// PUT - Update session
router.put('/:id', async (req, res) => {
    try {
        const { userId, category, duration, notes, date } = req.body;
        
        await Session.findByIdAndUpdate(req.params.id, {
            category,
            duration: parseInt(duration),
            notes: notes || '',
            date: date ? new Date(date) : new Date()
        });
        
        res.redirect(`/sessions?userId=${userId}`);
    } catch (error) {
        console.error('Update session error:', error);
        res.status(500).send('Error updating session');
    }
});

// DELETE - Delete session
router.delete('/:id', async (req, res) => {
    try {
        const userId = req.query.userId || req.body.userId;
        await Session.findByIdAndDelete(req.params.id);
        res.redirect(`/sessions?userId=${userId}`);
    } catch (error) {
        console.error('Delete session error:', error);
        res.status(500).send('Error deleting session');
    }
});

module.exports = router;
