const express = require('express');
const router = express.Router();
const Session = require('../models/Session');
const Goal = require('../models/Goal');
const Mood = require('../models/Mood');
const User = require('../models/User');

// GET - Insights page
router.get('/', async (req, res) => {
    try {
        const userId = req.query.userId;
        
        if (!userId) {
            return res.redirect('/');
        }
        
        const user = await User.findById(userId);
        const timeRange = req.query.range || '7days';
        
        // Calculate date range
        const now = new Date();
        let startDate = new Date();
        
        switch(timeRange) {
            case '7days':
                startDate.setDate(now.getDate() - 7);
                break;
            case '30days':
                startDate.setDate(now.getDate() - 30);
                break;
            case '90days':
                startDate.setDate(now.getDate() - 90);
                break;
        }
        
        // Get sessions in range
        const sessions = await Session.find({
            userId,
            date: { $gte: startDate, $lte: now }
        }).sort({ date: 1 });
        
        // Get goals
        const goals = await Goal.find({ userId });
        const activeGoals = goals.filter(g => !g.isCompleted);
        const completedGoals = goals.filter(g => g.isCompleted);
        
        // Get moods in range
        const moods = await Mood.find({
            userId,
            date: { $gte: startDate, $lte: now }
        }).sort({ date: 1 });
        
        // Calculate statistics
        const totalScreenTime = sessions.reduce((sum, s) => sum + s.duration, 0);
        const daysInRange = Math.ceil((now - startDate) / (1000 * 60 * 60 * 24));
        const dailyAverage = daysInRange > 0 ? Math.round(totalScreenTime / daysInRange) : 0;
        
        // Category breakdown
        const categoryTotals = {};
        sessions.forEach(s => {
            categoryTotals[s.category] = (categoryTotals[s.category] || 0) + s.duration;
        });
        
        // Average mood
        const averageMoodScore = moods.length > 0 
            ? (moods.reduce((sum, m) => sum + m.moodScore, 0) / moods.length).toFixed(1)
            : 3;
        
        const moodNames = ['', 'Struggling', 'Down', 'Okay', 'Good', 'Excellent'];
        const averageMoodName = moodNames[Math.round(averageMoodScore)] || 'Okay';
        
        // Prepare chart data
        const last7Days = [];
        for (let i = 6; i >= 0; i--) {
            const date = new Date();
            date.setDate(date.getDate() - i);
            last7Days.push({
                date: date,
                label: date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })
            });
        }
        
        const trendData = last7Days.map(day => {
            const dayStart = new Date(day.date);
            dayStart.setHours(0, 0, 0, 0);
            const dayEnd = new Date(day.date);
            dayEnd.setHours(23, 59, 59, 999);
            
            const daySessions = sessions.filter(s => {
                const sessionDate = new Date(s.date);
                return sessionDate >= dayStart && sessionDate <= dayEnd;
            });
            
            const total = daySessions.reduce((sum, s) => sum + s.duration, 0);
            return {
                label: day.label,
                value: (total / 60).toFixed(1) // Convert to hours
            };
        });
        
        // Mood correlation data
        const moodCorrelation = moods.map(m => ({
            screenTime: (m.screenTime / 60).toFixed(1),
            moodScore: m.moodScore
        }));
        
        res.render('insights', {
            title: 'Insights - Hypnos',
            user,
            timeRange,
            stats: {
                totalScreenTime,
                dailyAverage,
                goalsAchieved: completedGoals.length,
                totalGoals: goals.length,
                averageMood: averageMoodName
            },
            categoryTotals,
            trendData: JSON.stringify(trendData),
            moodCorrelation: JSON.stringify(moodCorrelation),
            activeGoals
        });
    } catch (error) {
        console.error('Insights page error:', error);
        res.status(500).send('Error loading insights');
    }
});

module.exports = router;
