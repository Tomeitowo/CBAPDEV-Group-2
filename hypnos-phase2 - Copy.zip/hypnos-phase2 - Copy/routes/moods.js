const express = require('express');
const router = express.Router();
const Mood = require('../models/Mood');
const User = require('../models/User');
const Session = require('../models/Session');

// GET - Moods page
router.get('/', async (req, res) => {
    try {
        const userId = req.query.userId;
        
        if (!userId) {
            return res.redirect('/');
        }
        
        const user = await User.findById(userId);
        
        const moods = await Mood.find({ userId })
            .sort({ date: -1 })
            .limit(30);
        
        // Calculate stats
        const totalMoods = moods.length;
        const averageMood = totalMoods > 0 
            ? (moods.reduce((sum, m) => sum + m.moodScore, 0) / totalMoods).toFixed(1)
            : 0;
        
        const moodCounts = {
            Excellent: moods.filter(m => m.mood === 'Excellent').length,
            Good: moods.filter(m => m.mood === 'Good').length,
            Okay: moods.filter(m => m.mood === 'Okay').length,
            Down: moods.filter(m => m.mood === 'Down').length,
            Struggling: moods.filter(m => m.mood === 'Struggling').length
        };
        
        res.render('moods', {
            title: 'Mood Tracker - Hypnos',
            user,
            moods,
            stats: {
                totalEntries: totalMoods,
                averageMood,
                moodCounts
            }
        });
    } catch (error) {
        console.error('Moods page error:', error);
        res.status(500).send('Error loading moods');
    }
});

// POST - Create new mood entry
router.post('/', async (req, res) => {
    try {
        const { userId, mood, notes, date } = req.body;
        
        // Map mood to score
        const moodScores = {
            'Excellent': 5,
            'Good': 4,
            'Okay': 3,
            'Down': 2,
            'Struggling': 1
        };
        
        // Calculate screen time for the day
        const selectedDate = date ? new Date(date) : new Date();
        const startOfDay = new Date(selectedDate);
        startOfDay.setHours(0, 0, 0, 0);
        const endOfDay = new Date(selectedDate);
        endOfDay.setHours(23, 59, 59, 999);
        
        const sessions = await Session.find({
            userId,
            date: { $gte: startOfDay, $lte: endOfDay }
        });
        
        const totalScreenTime = sessions.reduce((sum, s) => sum + s.duration, 0);
        
        const moodEntry = new Mood({
            userId,
            mood,
            moodScore: moodScores[mood],
            notes: notes || '',
            date: selectedDate,
            screenTime: totalScreenTime
        });
        
        await moodEntry.save();
        res.redirect(`/moods?userId=${userId}`);
    } catch (error) {
        console.error('Create mood error:', error);
        res.status(500).send('Error creating mood entry');
    }
});

// GET - Edit mood page
router.get('/:id/edit', async (req, res) => {
    try {
        const userId = req.query.userId;
        const mood = await Mood.findById(req.params.id);
        const user = await User.findById(userId);
        
        if (!mood) {
            return res.redirect(`/moods?userId=${userId}`);
        }
        
        res.render('moods-edit', {
            title: 'Edit Mood - Hypnos',
            user,
            mood
        });
    } catch (error) {
        console.error('Edit mood page error:', error);
        res.status(500).send('Error loading edit page');
    }
});

// PUT - Update mood
router.put('/:id', async (req, res) => {
    try {
        const { userId, mood, notes } = req.body;
        
        const moodScores = {
            'Excellent': 5,
            'Good': 4,
            'Okay': 3,
            'Down': 2,
            'Struggling': 1
        };
        
        await Mood.findByIdAndUpdate(req.params.id, {
            mood,
            moodScore: moodScores[mood],
            notes: notes || ''
        });
        
        res.redirect(`/moods?userId=${userId}`);
    } catch (error) {
        console.error('Update mood error:', error);
        res.status(500).send('Error updating mood');
    }
});

// DELETE - Delete mood
router.delete('/:id', async (req, res) => {
    try {
        const userId = req.query.userId || req.body.userId;
        await Mood.findByIdAndDelete(req.params.id);
        res.redirect(`/moods?userId=${userId}`);
    } catch (error) {
        console.error('Delete mood error:', error);
        res.status(500).send('Error deleting mood');
    }
});

module.exports = router;
