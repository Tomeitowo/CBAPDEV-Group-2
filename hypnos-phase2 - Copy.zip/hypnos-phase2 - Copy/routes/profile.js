const express = require('express');
const router = express.Router();
const User = require('../models/User');
const Session = require('../models/Session');
const Goal = require('../models/Goal');
const Mood = require('../models/Mood');

// GET - Profile page
router.get('/', async (req, res) => {
    try {
        const userId = req.query.userId;
        
        if (!userId) {
            return res.redirect('/');
        }
        
        const user = await User.findById(userId);
        
        if (!user) {
            return res.redirect('/?error=User not found');
        }
        
        res.render('profile', {
            title: 'Profile - Hypnos',
            user,
            message: req.query.message
        });
    } catch (error) {
        console.error('Profile page error:', error);
        res.status(500).send('Error loading profile');
    }
});

// POST - Update profile
router.post('/update', async (req, res) => {
    try {
        const { userId, updateUsername, updateEmail, updateFullName } = req.body;
        
        // Check if username is taken by another user
        const existingUser = await User.findOne({ 
            username: updateUsername,
            _id: { $ne: userId }
        });
        
        if (existingUser) {
            return res.redirect(`/profile?userId=${userId}&message=error-username`);
        }
        
        // Check if email is taken by another user
        const existingEmail = await User.findOne({ 
            email: updateEmail,
            _id: { $ne: userId }
        });
        
        if (existingEmail) {
            return res.redirect(`/profile?userId=${userId}&message=error-email`);
        }
        
        await User.findByIdAndUpdate(userId, {
            username: updateUsername,
            email: updateEmail,
            fullName: updateFullName || updateUsername
        });
        
        res.redirect(`/profile?userId=${userId}&message=success-profile`);
    } catch (error) {
        console.error('Update profile error:', error);
        res.redirect(`/profile?userId=${req.body.userId}&message=error-update`);
    }
});

// POST - Change password
router.post('/change-password', async (req, res) => {
    try {
        const { userId, currentPassword, newPasswordProfile, confirmPasswordProfile } = req.body;
        
        const user = await User.findById(userId);
        
        // Verify current password
        if (user.password !== currentPassword) {
            return res.redirect(`/profile?userId=${userId}&message=error-current-password`);
        }
        
        // Check if new passwords match
        if (newPasswordProfile !== confirmPasswordProfile) {
            return res.redirect(`/profile?userId=${userId}&message=error-password-match`);
        }
        
        // Update password (In Phase 3, this will be hashed)
        user.password = newPasswordProfile;
        await user.save();
        
        res.redirect(`/profile?userId=${userId}&message=success-password`);
    } catch (error) {
        console.error('Change password error:', error);
        res.redirect(`/profile?userId=${req.body.userId}&message=error-password`);
    }
});

// DELETE - Delete account
router.delete('/delete', async (req, res) => {
    try {
        const userId = req.body.userId;
        
        // Delete all user data
        await Session.deleteMany({ userId });
        await Goal.deleteMany({ userId });
        await Mood.deleteMany({ userId });
        await User.findByIdAndDelete(userId);
        
        res.redirect('/?message=account-deleted');
    } catch (error) {
        console.error('Delete account error:', error);
        res.redirect(`/profile?userId=${req.body.userId}&message=error-delete`);
    }
});

module.exports = router;
