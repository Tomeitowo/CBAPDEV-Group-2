const express = require('express');
const router = express.Router();
const User = require('../models/User');

// GET - Login page
router.get('/', (req, res) => {
    res.render('index', { 
        title: 'Login - Hypnos',
        error: req.query.error
    });
});

// POST - Login
router.post('/login', async (req, res) => {
    try {
        const { username, password } = req.body;
        
        // Find user
        const user = await User.findOne({ username, password });
        
        if (!user) {
            return res.redirect('/?error=Invalid username or password');
        }
        
        // In Phase 3, we'll use proper session management
        // For now, redirect to home with user ID in query
        res.redirect(`/home?userId=${user._id}`);
    } catch (error) {
        console.error('Login error:', error);
        res.redirect('/?error=An error occurred during login');
    }
});

// GET - Register page
router.get('/register', (req, res) => {
    res.render('register', { 
        title: 'Register - Hypnos',
        error: req.query.error
    });
});

// POST - Register
router.post('/register', async (req, res) => {
    try {
        const { newUsername, email, newPassword, confirmPassword } = req.body;
        
        // Check if passwords match
        if (newPassword !== confirmPassword) {
            return res.redirect('/register?error=Passwords do not match');
        }
        
        // Check if username exists
        const existingUser = await User.findOne({ username: newUsername });
        if (existingUser) {
            return res.redirect('/register?error=Username already exists');
        }
        
        // Check if email exists
        const existingEmail = await User.findOne({ email });
        if (existingEmail) {
            return res.redirect('/register?error=Email already registered');
        }
        
        // Create new user
        const user = new User({
            username: newUsername,
            password: newPassword, // In Phase 3, this will be hashed
            email,
            fullName: newUsername // Default, can be updated in profile
        });
        
        await user.save();
        
        res.redirect('/?success=Account created successfully');
    } catch (error) {
        console.error('Registration error:', error);
        res.redirect('/register?error=An error occurred during registration');
    }
});

// GET - Home/Dashboard
router.get('/home', async (req, res) => {
    try {
        const userId = req.query.userId;
        
        if (!userId) {
            return res.redirect('/');
        }
        
        const user = await User.findById(userId);
        
        if (!user) {
            return res.redirect('/?error=User not found');
        }
        
        res.render('home', {
            title: 'Dashboard - Hypnos',
            user,
            userName: user.fullName || user.username
        });
    } catch (error) {
        console.error('Home page error:', error);
        res.redirect('/');
    }
});

// GET - Logout
router.get('/logout', (req, res) => {
    // In Phase 3, we'll destroy the session here
    res.redirect('/');
});

module.exports = router;
