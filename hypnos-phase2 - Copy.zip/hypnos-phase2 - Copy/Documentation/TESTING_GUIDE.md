# Hypnos Phase 2 - Testing Guide

## Manual Testing Checklist

### 1. Authentication Flow

#### Registration ✓
- [ ] Navigate to registration page from login
- [ ] Fill all required fields
- [ ] Submit form
- [ ] Verify redirect to login with success message
- [ ] Test duplicate username error
- [ ] Test duplicate email error
- [ ] Test password mismatch error

#### Login ✓
- [ ] Enter valid credentials
- [ ] Verify redirect to dashboard
- [ ] Test invalid username error
- [ ] Test invalid password error
- [ ] Verify user name displays on dashboard

#### Logout ✓
- [ ] Click logout button
- [ ] Verify redirect to login page

### 2. Sessions (Activity Tracking)

#### Create (POST) ✓
- [ ] Navigate to Sessions page
- [ ] Click "Add Session" button
- [ ] Select category from dropdown
- [ ] Enter duration (minutes)
- [ ] Add notes (optional)
- [ ] Select date
- [ ] Submit form
- [ ] Verify new session appears in list

#### Read (GET) ✓
- [ ] View all sessions on page load
- [ ] Verify sessions display correctly
- [ ] Check date formatting
- [ ] Check duration formatting (hours/minutes)
- [ ] Test search functionality
- [ ] Search by category
- [ ] Search by notes content

#### Update (PUT) ✓
- [ ] Click "Edit" on a session
- [ ] Modify category
- [ ] Change duration
- [ ] Update notes
- [ ] Submit changes
- [ ] Verify updates persist

#### Delete (DELETE) ✓
- [ ] Click "Delete" on a session
- [ ] Confirm deletion dialog
- [ ] Verify session removed from list
- [ ] Check database to confirm deletion

### 3. Goals

#### Create (POST) ✓
- [ ] Navigate to Goals page
- [ ] Click "Add Goal" button
- [ ] Enter goal name
- [ ] Select category
- [ ] Add description
- [ ] Set target time
- [ ] Submit form
- [ ] Verify goal appears in Active Goals

#### Read (GET) ✓
- [ ] View active goals section
- [ ] View completed goals section
- [ ] Check streak display
- [ ] Verify target time formatting
- [ ] Test search functionality

#### Update (PUT) ✓
- [ ] Click "Edit" on a goal
- [ ] Modify name and details
- [ ] Submit changes
- [ ] Verify updates persist

#### Toggle Completion (POST) ✓
- [ ] Mark active goal as complete
- [ ] Verify move to Completed section
- [ ] Check completion date added
- [ ] Reactivate completed goal
- [ ] Verify move back to Active section

#### Delete (DELETE) ✓
- [ ] Delete goal from Active Goals
- [ ] Delete goal from Completed Goals
- [ ] Confirm both work correctly

### 4. Mood Tracker

#### Create (POST) ✓
- [ ] Navigate to Moods page
- [ ] Click "Log Mood" button
- [ ] Select mood (Excellent to Struggling)
- [ ] Add notes (optional)
- [ ] Select date
- [ ] Submit form
- [ ] Verify mood entry appears
- [ ] Check emoji displays correctly
- [ ] Verify screen time calculated

#### Read (GET) ✓
- [ ] View all mood entries
- [ ] Check statistics display (total entries, average)
- [ ] Verify date formatting
- [ ] Check screen time correlation

#### Update (PUT) ✓
- [ ] Click "Edit" on mood entry
- [ ] Change mood level
- [ ] Update notes
- [ ] Submit changes
- [ ] Verify updates persist

#### Delete (DELETE) ✓
- [ ] Click "Delete" on mood entry
- [ ] Confirm deletion
- [ ] Verify removal from list

### 5. Insights & Analytics

#### View Analytics (GET) ✓
- [ ] Navigate to Insights page
- [ ] Verify stats cards display:
  - Total screen time
  - Daily average
  - Goals achieved
  - Average mood
- [ ] Check trend chart renders
- [ ] Verify chart data accuracy
- [ ] Check category breakdown

#### Filter Data (GET) ✓
- [ ] Select "Last 7 Days"
- [ ] Verify data updates
- [ ] Select "Last 30 Days"
- [ ] Verify data updates
- [ ] Select "Last 90 Days"
- [ ] Verify data updates

### 6. Profile Management

#### View Profile (GET) ✓
- [ ] Navigate to Profile page
- [ ] Verify user info displays:
  - Username
  - Email
  - Full name
  - Member since date

#### Update Profile (POST) ✓
- [ ] Change username
- [ ] Change email
- [ ] Change full name
- [ ] Submit form
- [ ] Verify success message
- [ ] Test duplicate username error
- [ ] Test duplicate email error
- [ ] Verify updates persist

#### Change Password (POST) ✓
- [ ] Enter current password
- [ ] Enter new password
- [ ] Confirm new password
- [ ] Submit form
- [ ] Verify success message
- [ ] Test incorrect current password error
- [ ] Test password mismatch error
- [ ] Try logging in with new password

#### Delete Account (DELETE) ✓
- [ ] Click "Delete Account" button
- [ ] Confirm deletion in modal
- [ ] Verify redirect to login
- [ ] Verify account removed from database
- [ ] Verify all user data deleted:
  - Sessions
  - Goals
  - Moods

### 7. Navigation & UX

#### Header Navigation ✓
- [ ] Click "Hypnos" logo
- [ ] Verify Dashboard button works
- [ ] Verify Profile button works
- [ ] Verify Logout button works

#### Dashboard Cards ✓
- [ ] Click "Sessions" card
- [ ] Click "Goals" card
- [ ] Click "Mood" card
- [ ] Click "Insights" card
- [ ] Verify all navigate correctly

#### Back Navigation ✓
- [ ] Test back button on each page
- [ ] Verify returns to dashboard with userId

### 8. Database Verification

#### Check MongoDB ✓
```bash
# Connect to MongoDB
mongosh

# Switch to database
use hypnos

# Check collections
show collections

# Count documents
db.users.countDocuments()
db.sessions.countDocuments()
db.goals.countDocuments()
db.moods.countDocuments()

# View sample data
db.users.findOne()
db.sessions.find().limit(1)
db.goals.find().limit(1)
db.moods.find().limit(1)
```

### 9. Error Handling

#### Test Error Scenarios ✓
- [ ] Navigate to non-existent route (404 page)
- [ ] Try to access features without userId
- [ ] Test with invalid ObjectId in URL
- [ ] Submit empty forms
- [ ] Test with extremely long input
- [ ] Test special characters in text fields

### 10. Data Validation

#### Required Fields ✓
- [ ] Try submitting forms without required fields
- [ ] Verify HTML5 validation works
- [ ] Check server-side validation

#### Data Types ✓
- [ ] Test negative duration values
- [ ] Test zero duration
- [ ] Test very large numbers
- [ ] Test date edge cases

## Sample Test Data

### Test Session Creation
```
Category: Social Media
Duration: 120
Date: Today
Notes: Testing Instagram browsing
```

### Test Goal Creation
```
Name: Limit Evening Screen Time
Category: Overall
Description: No screens after 9 PM
Target Time: 0
```

### Test Mood Entry
```
Mood: Good
Date: Today
Notes: Productive work day
```

## Browser Compatibility

Test in:
- [ ] Chrome
- [ ] Firefox
- [ ] Safari
- [ ] Edge

## Performance Checks

- [ ] Page load times < 2 seconds
- [ ] Charts render smoothly
- [ ] No console errors
- [ ] Database queries efficient

## Security Checks (Phase 2 Level)

- [ ] URLs require userId parameter
- [ ] Cannot access other users' data directly
- [ ] Form submissions validated
- [ ] Delete confirmations work

**Note**: Full security (sessions, password hashing, middleware auth) will be in Phase 3.

## Known Limitations (Phase 2)

❌ **Not Yet Implemented:**
- Session management (userId in URL)
- Password hashing (plaintext passwords)
- Authentication middleware
- CSRF protection
- Rate limiting
- Input sanitization
- XSS prevention

✅ **Will be Added in Phase 3**

## Bug Report Template

If you find issues, document them:

```
**Title**: Brief description

**Steps to Reproduce**:
1. Go to...
2. Click on...
3. Enter...
4. See error

**Expected**: What should happen

**Actual**: What actually happens

**Environment**:
- OS: 
- Browser: 
- Node version:
- MongoDB version:
```

## Testing Commands

```bash
# Start server
npm start

# Reset database
npm run seed

# Check database
mongosh
use hypnos
db.stats()

# View logs
tail -f logs/app.log  # if implemented
```

## Success Criteria

Phase 2 is complete when:
- ✅ All CRUD operations work
- ✅ All routes accessible
- ✅ Navigation links functional
- ✅ Database properly structured
- ✅ 5+ sample data per collection
- ✅ Handlebars renders correctly
- ✅ Forms submit with proper HTTP methods
- ✅ No critical bugs
- ✅ Server runs on localhost:3000

---

**Happy Testing!** 🧪
