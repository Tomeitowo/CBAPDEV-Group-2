const express = require('express');
const hbs = require('hbs');
const path = require('path');
const bodyParser = require('body-parser');
const methodOverride = require('method-override');
require('dotenv').config();

// Import database connection
const connectDB = require('./config/database');

// Import routes
const indexRoutes = require('./routes/index');
const sessionRoutes = require('./routes/sessions');
const goalRoutes = require('./routes/goals');
const moodRoutes = require('./routes/moods');
const insightRoutes = require('./routes/insights');
const profileRoutes = require('./routes/profile');

const app = express();
const PORT = process.env.PORT || 3000;

// Connect to MongoDB
connectDB();

// View engine setup
app.set('view engine', 'hbs');
app.set('views', path.join(__dirname, 'views'));

// Register partials directory
hbs.registerPartials(path.join(__dirname, 'views/partials'));

// Register Handlebars helpers
hbs.registerHelper('eq', function(a, b) {
    return a === b;
});

hbs.registerHelper('formatDate', function(date) {
    if (!date) return '';
    const d = new Date(date);
    return d.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
});

hbs.registerHelper('formatTime', function(minutes) {
    if (!minutes) return '0h 0m';
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    return `${hours}h ${mins}m`;
});

hbs.registerHelper('formatDateTime', function(date) {
    if (!date) return '';
    const d = new Date(date);
    return d.toLocaleString('en-US', { 
        year: 'numeric', 
        month: 'short', 
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
});

hbs.registerHelper('progressPercentage', function(current, target) {
    if (!target || target === 0) return 0;
    return Math.round((current / target) * 100);
});

hbs.registerHelper('getMoodEmoji', function(mood) {
    const emojis = {
        'Excellent': '😄',
        'Good': '🙂',
        'Okay': '😐',
        'Down': '😔',
        'Struggling': '😢'
    };
    return emojis[mood] || '😐';
});

// ADD THIS NEW HELPER:
hbs.registerHelper('getCategoryClass', function(category) {
    if (category === 'Social Media') return 'social-media';
    else if (category === 'Work' || category === 'Work-related') return 'work';
    else if (category === 'Gaming') return 'gaming';
    else if (category === 'Movies' || category === 'Movies & Entertainment') return 'movies';
    else if (category === 'Study' || category === 'Study & Learning') return 'study';
    else return 'other';
});

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(methodOverride('_method'));
app.use(express.static(path.join(__dirname, 'public')));

// Routes
app.use('/', indexRoutes);
app.use('/sessions', sessionRoutes);
app.use('/goals', goalRoutes);
app.use('/moods', moodRoutes);
app.use('/insights', insightRoutes);
app.use('/profile', profileRoutes);

// 404 handler
app.use((req, res) => {
    res.status(404).render('404', { title: 'Page Not Found' });
});

// Error handler
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).render('error', { 
        title: 'Error',
        message: 'Something went wrong!',
        error: process.env.NODE_ENV === 'development' ? err : {}
    });
});

// Start server
app.listen(PORT, () => {
    console.log(`🚀 Hypnos server running on http://localhost:${PORT}`);
    console.log(`📊 Environment: ${process.env.NODE_ENV}`);
});

module.exports = app;
