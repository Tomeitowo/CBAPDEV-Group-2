#!/usr/bin/env node

/**
 * Hypnos Setup Verification Script
 * Run this to check if everything is properly configured
 */

const fs = require('fs');
const path = require('path');

console.log('🔍 Hypnos Setup Verification\n');
console.log('='.repeat(50));

let allChecks = true;

// Check 1: Node.js version
console.log('\n📦 Checking Node.js version...');
const nodeVersion = process.version;
const majorVersion = parseInt(nodeVersion.slice(1).split('.')[0]);
if (majorVersion >= 14) {
    console.log(`✅ Node.js ${nodeVersion} (OK)`);
} else {
    console.log(`❌ Node.js ${nodeVersion} (Need v14 or higher)`);
    allChecks = false;
}

// Check 2: Required files
console.log('\n📁 Checking required files...');
const requiredFiles = [
    'server.js',
    'package.json',
    '.env',
    'config/database.js',
    'config/seed.js',
    'models/User.js',
    'models/Session.js',
    'models/Goal.js',
    'models/Mood.js',
    'routes/index.js',
    'views/index.hbs',
    'public/css/styles.css'
];

requiredFiles.forEach(file => {
    if (fs.existsSync(file)) {
        console.log(`✅ ${file}`);
    } else {
        console.log(`❌ ${file} (Missing)`);
        allChecks = false;
    }
});

// Check 3: node_modules
console.log('\n📚 Checking dependencies...');
if (fs.existsSync('node_modules')) {
    console.log('✅ node_modules folder exists');
    
    // Check key dependencies
    const deps = ['express', 'mongoose', 'hbs', 'dotenv'];
    deps.forEach(dep => {
        if (fs.existsSync(`node_modules/${dep}`)) {
            console.log(`  ✅ ${dep} installed`);
        } else {
            console.log(`  ❌ ${dep} not installed`);
            allChecks = false;
        }
    });
} else {
    console.log('❌ node_modules not found. Run: npm install');
    allChecks = false;
}

// Check 4: .env configuration
console.log('\n⚙️  Checking configuration...');
if (fs.existsSync('.env')) {
    const envContent = fs.readFileSync('.env', 'utf8');
    if (envContent.includes('PORT=')) {
        console.log('✅ PORT configured');
    }
    if (envContent.includes('MONGODB_URI=')) {
        console.log('✅ MONGODB_URI configured');
    }
} else {
    console.log('❌ .env file missing');
    allChecks = false;
}

// Check 5: Directory structure
console.log('\n📂 Checking directory structure...');
const requiredDirs = ['config', 'models', 'routes', 'views', 'public'];
requiredDirs.forEach(dir => {
    if (fs.existsSync(dir)) {
        console.log(`✅ ${dir}/ directory exists`);
    } else {
        console.log(`❌ ${dir}/ directory missing`);
        allChecks = false;
    }
});

// Summary
console.log('\n' + '='.repeat(50));
if (allChecks) {
    console.log('\n✨ All checks passed! You\'re ready to go!\n');
    console.log('Next steps:');
    console.log('1. Start MongoDB: mongod');
    console.log('2. Seed database: npm run seed');
    console.log('3. Start server: npm start');
    console.log('4. Open browser: http://localhost:3000\n');
} else {
    console.log('\n⚠️  Some checks failed. Please fix the issues above.\n');
    console.log('Common fixes:');
    console.log('- Run: npm install');
    console.log('- Ensure all files are present');
    console.log('- Check .env configuration\n');
    process.exit(1);
}
