# Hypnos - Screen Time Management Web Application (Phase 2)

## Project Overview
Hypnos is a comprehensive web application designed to help users track, manage, and reduce their screen time through features like activity tracking, goal setting, mood tracking, and insightful analytics.

**Phase 2 Completion:** This version includes full backend implementation with Node.js, Express, MongoDB, and Handlebars templating.

## Technologies Used

### Backend
- **Node.js** - JavaScript runtime
- **Express.js** - Web application framework
- **MongoDB** - NoSQL database
- **Mongoose** - MongoDB ODM
- **Handlebars (hbs)** - Template engine

### Frontend
- HTML5
- CSS3
- JavaScript
- Chart.js - Data visualizations

## Project Structure

```
hypnos-phase2/
├── config/
│   ├── database.js          # MongoDB connection
│   └── seed.js              # Database seeding script
├── models/
│   ├── User.js              # User schema
│   ├── Session.js           # Activity session schema
│   ├── Goal.js              # Goal schema
│   └── Mood.js              # Mood entry schema
├── routes/
│   ├── index.js             # Authentication & home routes
│   ├── sessions.js          # Session CRUD routes
│   ├── goals.js             # Goal CRUD routes
│   ├── moods.js             # Mood CRUD routes
│   ├── insights.js          # Analytics routes
│   └── profile.js           # Profile management routes
├── views/
│   ├── layouts/
│   │   └── main.hbs         # Main layout template
│   ├── partials/
│   │   └── header.hbs       # Header partial
│   ├── index.hbs            # Login page
│   ├── register.hbs         # Registration page
│   ├── home.hbs             # Dashboard
│   ├── sessions.hbs         # Sessions page
│   ├── sessions-edit.hbs    # Edit session page
│   ├── goals.hbs            # Goals page
│   ├── goals-edit.hbs       # Edit goal page
│   ├── moods.hbs            # Moods page
│   ├── moods-edit.hbs       # Edit mood page
│   ├── insights.hbs         # Analytics page
│   └── profile.hbs          # Profile page
├── public/
│   └── css/
│       └── styles.css       # Application styles
├── server.js                # Main application entry point
├── package.json             # Dependencies
├── .env                     # Environment variables
└── README.md                # This file
```

## Prerequisites

Before running this application, ensure you have the following installed:

1. **Node.js** (v14 or higher)
   - Download from: https://nodejs.org/
   - Verify installation: `node --version`

2. **MongoDB** (v4.4 or higher)
   - Download from: https://www.mongodb.com/try/download/community
   - Or use MongoDB Atlas (cloud): https://www.mongodb.com/cloud/atlas
   - Verify installation: `mongod --version`

3. **npm** (comes with Node.js)
   - Verify installation: `npm --version`

## Installation & Setup

### Step 1: Clone or Download the Project

```bash
# If you have the project files, navigate to the project directory
cd hypnos-phase2
```

### Step 2: Install Dependencies

```bash
npm install
```

This will install all required packages:
- express
- hbs (Handlebars)
- mongoose
- body-parser
- dotenv
- method-override
- nodemon (dev dependency)

### Step 3: Start MongoDB

**Option A: Local MongoDB**
```bash
# On Windows
mongod

# On macOS/Linux
sudo mongod
```

MongoDB should now be running on `mongodb://localhost:27017`

**Option B: MongoDB Atlas (Cloud)**
1. Create a free account at https://www.mongodb.com/cloud/atlas
2. Create a new cluster
3. Get your connection string
4. Update the `MONGODB_URI` in `.env` file with your connection string

### Step 4: Configure Environment Variables

The `.env` file is already configured for local development:

```env
PORT=3000
NODE_ENV=development
MONGODB_URI=mongodb://localhost:27017/hypnos
```

If using MongoDB Atlas, update `MONGODB_URI`:
```env
MONGODB_URI=mongodb+srv://username:password@cluster.mongodb.net/hypnos
```

### Step 5: Seed the Database

Populate the database with sample data:

```bash
npm run seed
```

This will create:
- **5 sample users** (with hardcoded credentials)
- **8+ activity sessions**
- **6 goals** (4 active, 2 completed)
- **7 mood entries**

### Step 6: Start the Server

```bash
npm start
```

Or for development with auto-restart:
```bash
npm run dev
```

You should see:
```
✅ MongoDB Connected: localhost
📁 Database: hypnos
🚀 Hypnos server running on http://localhost:3000
📊 Environment: development
```

### Step 7: Access the Application

Open your browser and navigate to:
```
http://localhost:3000
```

## Default User Credentials

After seeding, you can login with any of these accounts:

| Username | Password |
|----------|----------|
| JohnMiguel | Hello!123 |
| JuanDelaCruz | Pilipinas |
| SophiaCruz | 12345 |
| JoseRizal | 54321 |
| MannyPacman | labanlang |

## Features & CRUD Operations

### 1. User Authentication
- **Login** (POST `/login`)
- **Register** (POST `/register`)
- **Logout** (GET `/logout`)

### 2. Activity Sessions
- **Create**: Add new screen time sessions
- **Read**: View all sessions with search functionality
- **Update**: Edit session details
- **Delete**: Remove sessions
- **Routes**: `/sessions`

### 3. Goals
- **Create**: Set new screen time goals
- **Read**: View active and completed goals with search
- **Update**: Modify goal parameters
- **Delete**: Remove goals
- **Toggle**: Mark goals as complete/active
- **Routes**: `/goals`

### 4. Mood Tracker
- **Create**: Log daily mood entries
- **Read**: View mood history and statistics
- **Update**: Edit mood entries
- **Delete**: Remove mood entries
- **Routes**: `/moods`

### 5. Insights & Analytics
- **View**: Screen time trends, category breakdown, goal progress
- **Filter**: By time range (7, 30, 90 days)
- **Charts**: Interactive visualizations using Chart.js
- **Routes**: `/insights`

### 6. Profile Management
- **View**: Account information
- **Update**: Username, email, full name
- **Change Password**: Update account password
- **Delete Account**: Permanently remove account and all data
- **Routes**: `/profile`

## Database Schema

### User Collection
```javascript
{
  username: String (required, unique),
  password: String (required),
  email: String (required, unique),
  fullName: String (required),
  memberSince: Date (default: now),
  isActive: Boolean (default: true)
}
```

### Session Collection
```javascript
{
  userId: ObjectId (ref: 'User'),
  category: String (enum: ['Social Media', 'Work', 'Gaming', 'Movies', 'Study', 'Other']),
  duration: Number (minutes),
  date: Date,
  notes: String
}
```

### Goal Collection
```javascript
{
  userId: ObjectId (ref: 'User'),
  name: String,
  category: String,
  description: String,
  targetTime: Number (minutes),
  currentStreak: Number,
  longestStreak: Number,
  status: String (enum: ['active', 'completed', 'paused']),
  isCompleted: Boolean,
  completedDate: Date
}
```

### Mood Collection
```javascript
{
  userId: ObjectId (ref: 'User'),
  mood: String (enum: ['Excellent', 'Good', 'Okay', 'Down', 'Struggling']),
  moodScore: Number (1-5),
  date: Date,
  notes: String,
  screenTime: Number (minutes)
}
```

## HTTP Methods Used

The application properly implements RESTful conventions:

- **GET** - Retrieve data (viewing pages, search queries)
- **POST** - Create new resources (login, register, create entries)
- **PUT** - Update existing resources (edit entries) - via method-override
- **DELETE** - Remove resources (delete entries) - via method-override

## API Endpoints

### Authentication
```
GET  /                  - Login page
POST /login             - Process login
GET  /register          - Registration page
POST /register          - Process registration
GET  /home              - Dashboard
GET  /logout            - Logout
```

### Sessions
```
GET    /sessions                  - View all sessions
POST   /sessions                  - Create session
GET    /sessions/:id/edit         - Edit session form
PUT    /sessions/:id              - Update session
DELETE /sessions/:id              - Delete session
```

### Goals
```
GET    /goals                     - View all goals
POST   /goals                     - Create goal
GET    /goals/:id/edit            - Edit goal form
PUT    /goals/:id                 - Update goal
POST   /goals/:id/toggle          - Toggle completion
DELETE /goals/:id                 - Delete goal
```

### Moods
```
GET    /moods                     - View all moods
POST   /moods                     - Create mood entry
GET    /moods/:id/edit            - Edit mood form
PUT    /moods/:id                 - Update mood
DELETE /moods/:id                 - Delete mood
```

### Insights & Profile
```
GET    /insights                  - View analytics
GET    /profile                   - View profile
POST   /profile/update            - Update profile
POST   /profile/change-password   - Change password
DELETE /profile/delete            - Delete account
```

## Troubleshooting

### MongoDB Connection Issues

**Problem**: Cannot connect to MongoDB
```
Error: connect ECONNREFUSED 127.0.0.1:27017
```

**Solution**:
1. Ensure MongoDB is running: `mongod`
2. Check if port 27017 is available
3. Verify MONGODB_URI in `.env` file

### Port Already in Use

**Problem**: Port 3000 is already in use
```
Error: listen EADDRINUSE: address already in use :::3000
```

**Solution**:
1. Change PORT in `.env` to another port (e.g., 3001)
2. Or kill the process using port 3000

### Module Not Found

**Problem**: Cannot find module errors

**Solution**:
```bash
# Delete node_modules and reinstall
rm -rf node_modules package-lock.json
npm install
```

### Database Not Seeded

**Problem**: No data shows up in the application

**Solution**:
```bash
# Re-run the seed script
npm run seed
```

## Development Notes

### Phase 2 Implementation Details

✅ **Completed Requirements:**
- MVC-like architecture (preparing for Phase 3)
- MongoDB database with Mongoose ODM
- All CRUD operations functional
- Template engine (Handlebars) for views
- Proper HTTP methods (GET, POST, PUT, DELETE)
- Navigation links throughout application
- 5+ sample data entries for each feature
- Hosted on localhost:3000

⚠️ **Not Yet Implemented (Phase 3):**
- Session management (express-session)
- Password hashing (bcrypt)
- Form validation
- Middleware authentication guards
- Full MVC separation of concerns

## Future Enhancements (Phase 3)

- Implement express-session for proper authentication
- Add bcrypt for password hashing
- Create controllers for better MVC structure
- Add form validation (client and server-side)
- Implement authentication middleware
- Add error handling middleware
- Create custom 404 and error pages
- Add email verification
- Implement "Remember Me" functionality
- Add data export features

## Team & Credits

**Course**: Web Application Development
**Phase**: 2 - Backend Implementation
**Technology Stack**: Node.js + Express + MongoDB + Handlebars

## License

This project is for educational purposes as part of a web development course.

---

## Quick Start Commands

```bash
# Install dependencies
npm install

# Start MongoDB (if local)
mongod

# Seed database
npm run seed

# Start server
npm start

# Start development server (auto-restart)
npm run dev
```

## Support

If you encounter any issues:
1. Check this README thoroughly
2. Verify all prerequisites are installed
3. Ensure MongoDB is running
4. Check that all dependencies are installed
5. Review the console for error messages

---

**Last Updated**: Phase 2 Implementation  
**Server**: http://localhost:3000  
**Database**: MongoDB (Local or Atlas)
