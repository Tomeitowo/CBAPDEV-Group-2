const mongoose = require('mongoose');
require('dotenv').config();

const User = require('../models/User');
const Session = require('../models/Session');
const Goal = require('../models/Goal');
const Mood = require('../models/Mood');

const connectDB = require('./database');

// Sample users
const users = [
    {
        username: 'JohnMiguel',
        password: 'Hello!123', // Note: In Phase 3, this will be hashed
        email: 'john.miguel@email.com',
        fullName: 'John Miguel Santos'
    },
    {
        username: 'JuanDelaCruz',
        password: 'Pilipinas',
        email: 'juan.delacruz@email.com',
        fullName: 'Juan Dela Cruz'
    },
    {
        username: 'SophiaCruz',
        password: '12345',
        email: 'sophia.cruz@email.com',
        fullName: 'Sophia Cruz'
    },
    {
        username: 'JoseRizal',
        password: '54321',
        email: 'jose.rizal@email.com',
        fullName: 'Jose Rizal'
    },
    {
        username: 'MannyPacman',
        password: 'labanlang',
        email: 'manny.pacman@email.com',
        fullName: 'Manny Pacquiao'
    }
];

// Function to get dates relative to today
const getDaysAgo = (days) => {
    const date = new Date();
    date.setDate(date.getDate() - days);
    return date;
};

const seedDatabase = async () => {
    try {
        await connectDB();

        console.log('🗑️  Clearing existing data...');
        await User.deleteMany({});
        await Session.deleteMany({});
        await Goal.deleteMany({});
        await Mood.deleteMany({});

        console.log('👥 Creating users...');
        const createdUsers = await User.insertMany(users);
        console.log(`✅ Created ${createdUsers.length} users`);

        // Use first user for sample data
        const userId = createdUsers[0]._id;

        // Sample Sessions
        console.log('⏱️  Creating sessions...');
        const sessions = [
            {
                userId,
                category: 'Social Media',
                duration: 120,
                date: getDaysAgo(0),
                notes: 'Instagram and Twitter browsing'
            },
            {
                userId,
                category: 'Work',
                duration: 240,
                date: getDaysAgo(0),
                notes: 'Project development and emails'
            },
            {
                userId,
                category: 'Gaming',
                duration: 90,
                date: getDaysAgo(1),
                notes: 'League of Legends ranked matches'
            },
            {
                userId,
                category: 'Movies',
                duration: 135,
                date: getDaysAgo(1),
                notes: 'Watched Inception on Netflix'
            },
            {
                userId,
                category: 'Study',
                duration: 180,
                date: getDaysAgo(2),
                notes: 'Web development tutorials'
            },
            {
                userId,
                category: 'Social Media',
                duration: 75,
                date: getDaysAgo(2),
                notes: 'Facebook and YouTube'
            },
            {
                userId,
                category: 'Work',
                duration: 300,
                date: getDaysAgo(3),
                notes: 'Client meetings and documentation'
            },
            {
                userId,
                category: 'Gaming',
                duration: 150,
                date: getDaysAgo(4),
                notes: 'Valorant with friends'
            }
        ];
        const createdSessions = await Session.insertMany(sessions);
        console.log(`✅ Created ${createdSessions.length} sessions`);

        // Sample Goals
        console.log('🎯 Creating goals...');
        const goals = [
            {
                userId,
                name: 'Limit Social Media',
                category: 'Social Media',
                description: 'Reduce daily social media usage to under 2 hours',
                targetTime: 120,
                currentStreak: 3,
                longestStreak: 5,
                status: 'active',
                isCompleted: false
            },
            {
                userId,
                name: 'Productive Work Hours',
                category: 'Work',
                description: 'Maintain focused work sessions under 6 hours daily',
                targetTime: 360,
                currentStreak: 12,
                longestStreak: 15,
                status: 'active',
                isCompleted: false
            },
            {
                userId,
                name: 'Gaming Moderation',
                category: 'Gaming',
                description: 'Keep gaming time under 2 hours per day',
                targetTime: 120,
                currentStreak: 1,
                longestStreak: 4,
                status: 'active',
                isCompleted: false
            },
            {
                userId,
                name: 'Daily Study Time',
                category: 'Study',
                description: 'Dedicate at least 3 hours to learning',
                targetTime: 180,
                currentStreak: 7,
                longestStreak: 10,
                status: 'active',
                isCompleted: false
            },
            {
                userId,
                name: 'Screen-Free Evenings',
                category: 'Overall',
                description: 'No screens after 10 PM',
                targetTime: 0,
                currentStreak: 21,
                longestStreak: 21,
                status: 'completed',
                isCompleted: true,
                completedDate: getDaysAgo(0)
            },
            {
                userId,
                name: 'Morning Routine',
                category: 'Overall',
                description: 'Start day without checking phone for 1 hour',
                targetTime: 0,
                currentStreak: 14,
                longestStreak: 14,
                status: 'completed',
                isCompleted: true,
                completedDate: getDaysAgo(1)
            }
        ];
        const createdGoals = await Goal.insertMany(goals);
        console.log(`✅ Created ${createdGoals.length} goals`);

        // Sample Mood Entries
        console.log('😊 Creating mood entries...');
        const moods = [
            {
                userId,
                mood: 'Good',
                moodScore: 4,
                date: getDaysAgo(0),
                notes: 'Productive day at work',
                screenTime: 360
            },
            {
                userId,
                mood: 'Excellent',
                moodScore: 5,
                date: getDaysAgo(1),
                notes: 'Achieved my daily goals',
                screenTime: 225
            },
            {
                userId,
                mood: 'Okay',
                moodScore: 3,
                date: getDaysAgo(2),
                notes: 'Feeling neutral today',
                screenTime: 255
            },
            {
                userId,
                mood: 'Down',
                moodScore: 2,
                date: getDaysAgo(3),
                notes: 'Stressed about deadlines',
                screenTime: 300
            },
            {
                userId,
                mood: 'Good',
                moodScore: 4,
                date: getDaysAgo(4),
                notes: 'Had a great workout',
                screenTime: 150
            },
            {
                userId,
                mood: 'Excellent',
                moodScore: 5,
                date: getDaysAgo(5),
                notes: 'Completed major project milestone',
                screenTime: 330
            },
            {
                userId,
                mood: 'Okay',
                moodScore: 3,
                date: getDaysAgo(6),
                notes: 'Average day',
                screenTime: 420
            }
        ];
        const createdMoods = await Mood.insertMany(moods);
        console.log(`✅ Created ${createdMoods.length} mood entries`);

        console.log('\n✨ Database seeded successfully!');
        console.log('\n📊 Summary:');
        console.log(`   Users: ${createdUsers.length}`);
        console.log(`   Sessions: ${createdSessions.length}`);
        console.log(`   Goals: ${createdGoals.length}`);
        console.log(`   Moods: ${createdMoods.length}`);
        console.log('\n💡 You can now login with any of these users:');
        users.forEach(user => {
            console.log(`   - ${user.username} / ${user.password}`);
        });

        process.exit(0);
    } catch (error) {
        console.error('❌ Error seeding database:', error);
        process.exit(1);
    }
};

seedDatabase();
