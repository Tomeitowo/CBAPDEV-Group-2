# Hypnos Phase 2 - Quick Start Guide

## 🚀 Get Started in 5 Minutes

### Prerequisites Check
```bash
node --version    # Should be v14+
npm --version     # Should be v6+
mongod --version  # Should be v4.4+
```

### Installation Steps

1. **Navigate to project directory**
```bash
cd hypnos-phase2
```

2. **Install dependencies**
```bash
npm install
```

3. **Start MongoDB** (in a separate terminal)
```bash
mongod
```

4. **Seed the database**
```bash
npm run seed
```

5. **Start the server**
```bash
npm start
```

6. **Open browser**
```
http://localhost:3000
```

7. **Login with**
```
Username: JohnMiguel
Password: Hello!123
```

## 📁 Project Structure Overview

```
hypnos-phase2/
├── server.js              ← Main entry point
├── config/
│   ├── database.js        ← MongoDB connection
│   └── seed.js            ← Database seeding
├── models/                ← Mongoose schemas
│   ├── User.js
│   ├── Session.js
│   ├── Goal.js
│   └── Mood.js
├── routes/                ← Express routes (controllers)
│   ├── index.js           ← Auth & home
│   ├── sessions.js        ← Sessions CRUD
│   ├── goals.js           ← Goals CRUD
│   ├── moods.js           ← Moods CRUD
│   ├── insights.js        ← Analytics
│   └── profile.js         ← Profile management
├── views/                 ← Handlebars templates
└── public/                ← Static files (CSS)
```

## 🔑 Test Users

| Username | Password | Email |
|----------|----------|-------|
| JohnMiguel | Hello!123 | john.miguel@email.com |
| JuanDelaCruz | Pilipinas | juan.delacruz@email.com |
| SophiaCruz | 12345 | sophia.cruz@email.com |
| JoseRizal | 54321 | jose.rizal@email.com |
| MannyPacman | labanlang | manny.pacman@email.com |

## 📊 Sample Data Included

After seeding, you'll have:
- ✅ 5 Users
- ✅ 8 Activity Sessions
- ✅ 6 Goals (4 active, 2 completed)
- ✅ 7 Mood Entries

## 🎯 Features to Test

### 1. Sessions (Activity Tracking)
- Navigate to Sessions from dashboard
- Add new session with category, duration, notes
- Search sessions
- Edit and delete sessions

### 2. Goals
- Create new goals with target times
- Mark goals as complete
- Reactivate completed goals
- Edit and delete goals

### 3. Mood Tracker
- Log daily mood (Excellent → Struggling)
- View mood history
- See screen time correlation
- Edit and delete mood entries

### 4. Insights
- View screen time trends (Chart)
- See category breakdown
- Check goal progress
- Filter by time range (7/30/90 days)

### 5. Profile
- Update account info
- Change password
- Delete account (⚠️ permanent!)

## 🔧 Development Commands

```bash
# Normal start
npm start

# Development mode (auto-restart on changes)
npm run dev

# Re-seed database
npm run seed
```

## ❗ Common Issues

### MongoDB not starting?
```bash
# On Windows, run as administrator
mongod

# On macOS/Linux
sudo mongod
```

### Port 3000 in use?
Edit `.env` and change:
```
PORT=3001
```

### No data showing?
Run seed again:
```bash
npm run seed
```

## 🎨 Color Scheme

- Primary: #667eea (Purple-blue)
- Success: #48bb78 (Green)
- Warning: #ed8936 (Orange)
- Danger: #f56565 (Red)
- Info: #4299e1 (Blue)

## 📡 API Endpoints Quick Reference

### Auth
- `POST /login` - Login
- `POST /register` - Register
- `GET /logout` - Logout

### Sessions
- `GET /sessions` - List all
- `POST /sessions` - Create
- `PUT /sessions/:id` - Update
- `DELETE /sessions/:id` - Delete

### Goals
- `GET /goals` - List all
- `POST /goals` - Create
- `PUT /goals/:id` - Update
- `POST /goals/:id/toggle` - Toggle completion
- `DELETE /goals/:id` - Delete

### Moods
- `GET /moods` - List all
- `POST /moods` - Create
- `PUT /moods/:id` - Update
- `DELETE /moods/:id` - Delete

### Others
- `GET /insights` - Analytics
- `GET /profile` - View profile
- `POST /profile/update` - Update profile
- `POST /profile/change-password` - Change password
- `DELETE /profile/delete` - Delete account

## 📚 Technology Stack

- **Backend**: Node.js, Express.js
- **Database**: MongoDB with Mongoose ODM
- **Template Engine**: Handlebars (hbs)
- **Frontend**: HTML5, CSS3, JavaScript
- **Charts**: Chart.js

## ✅ Phase 2 Checklist

- [x] MongoDB database with Mongoose
- [x] 5+ sample data for each collection
- [x] Handlebars template engine
- [x] Full CRUD for all features
- [x] Proper HTTP methods (GET, POST, PUT, DELETE)
- [x] Navigation links throughout
- [x] Accessible at localhost:3000
- [x] MVC-like structure (preparing for Phase 3)

## 🔜 Coming in Phase 3

- Session management (express-session)
- Password hashing (bcrypt)
- Form validation
- Authentication middleware
- Full MVC separation
- Enhanced security

---

**Need Help?** Check the main README.md for detailed information.

**Ready to Start?** Run: `npm install && npm run seed && npm start`
