const express = require('express');

const controller = require('../controllers/profileController.js');

const app = express();

