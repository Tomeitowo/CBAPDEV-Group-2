exports.showProfile = function (req, res) {
    res.render('profile', {
        fn: 'Ned',
        ln: 'Stark',
    });
};