const express = require('express');
const path = require('path');

const profileController = require('../controllers/profileController.js');
const homeController = require('../controllers/homeController.js');
const registerController = require('../controllers/registerController.js');
const sessionsController = require('../controllers/sessionsController.js');
const goalsController = require('../controllers/goalsController.js');
const moodController = require('../controllers/moodController.js');
const insightsController = require('../controllers/insightsController.js');
const controller = require('../controllers/controller.js');

const app = express();

// Parse JSON bodies
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Page routes
app.get('/', controller.getIndex);
app.get('/profile', profileController.getProfile);
app.get('/register', registerController.getRegister);
app.get('/home', homeController.getHome);
app.get('/sessions', sessionsController.getSessions);
app.get('/goals', goalsController.getGoals);
app.get('/mood', moodController.getMood);
app.get('/insights', insightsController.getInsights);

// Mood API routes
app.post('/api/mood', moodController.createMood);
app.put('/api/mood/:id', moodController.updateMood);
app.delete('/api/mood/:id', moodController.deleteMood);

// Auth routes
app.post('/login', homeController.getHome);
app.post('/register', controller.getIndex);

module.exports = app;