
const profileController = {
    getProfile: async function (req, res) {
        res.render('profile');
    }
}

module.exports = profileController;