const path = require('path');

const controller = {
    getIndex: function (req, res) {
        res.render('index');
    }
}

module.exports = controller;