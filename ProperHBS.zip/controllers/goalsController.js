const goalsController = {
    getGoals: async function(req, res) {
        // Sample data to pass to the template
        const goalsData = {
            activeGoals: [
                {
                    id: 1,
                    name: "Reduce Social Media Time",
                    category: "Social Media",
                    categoryClass: "social-media",
                    description: "Limit social media usage to less than 1 hour per day",
                    currentTime: "0h 45m",
                    targetTime: "1h 00m",
                    progressPercentage: "75",
                    progressWidth: 75,
                    streak: 5,
                    statusClass: "active",
                    status: "On Track",
                    exceeded: false
                },
                {
                    id: 2,
                    name: "Work-Life Balance",
                    category: "Work-related",
                    categoryClass: "work",
                    description: "Keep work-related screen time under 6 hours per day",
                    currentTime: "4h 30m",
                    targetTime: "6h 00m",
                    progressPercentage: "75",
                    progressWidth: 75,
                    streak: 12,
                    statusClass: "active",
                    status: "On Track",
                    exceeded: false
                },
                {
                    id: 3,
                    name: "Gaming Moderation",
                    category: "Gaming",
                    categoryClass: "gaming",
                    description: "Limit gaming sessions to 2 hours per day maximum",
                    currentTime: "2h 30m",
                    targetTime: "2h 00m",
                    progressPercentage: "125",
                    progressWidth: 100,
                    streak: 3,
                    statusClass: "exceeded",
                    status: "Exceeded",
                    exceeded: true
                }
            ],
            completedGoals: [
                {
                    id: 4,
                    name: "Reduce Total Screen Time",
                    category: "General",
                    categoryClass: "other",
                    description: "Reduce daily screen time from 10 hours to 8 hours",
                    completedDate: "Oct 28, 2025"
                },
                {
                    id: 5,
                    name: "Entertainment Balance",
                    category: "Movies & Entertainment",
                    categoryClass: "movies",
                    description: "Keep entertainment screen time under 3 hours daily for 2 weeks",
                    completedDate: "Oct 15, 2025"
                }
            ]
        };

        res.render('goals', goalsData);
    }
};

module.exports = goalsController;