const sessionsController = {
    getSessions: async function (req, res) {
        // Sample sessions data
        const sessionsData = {
            sessions: [
                {
                    _id: 1,
                    category: "Social Media",
                    categoryClass: "social-media",
                    formattedDate: "November 4, 2025",
                    formattedDuration: "2h 15m",
                    hours: 2,
                    minutes: 15
                },
                {
                    _id: 2,
                    category: "Work-related",
                    categoryClass: "work",
                    formattedDate: "November 4, 2025",
                    formattedDuration: "4h 30m",
                    hours: 4,
                    minutes: 30
                },
                {
                    _id: 3,
                    category: "Gaming",
                    categoryClass: "gaming",
                    formattedDate: "November 3, 2025",
                    formattedDuration: "1h 45m",
                    hours: 1,
                    minutes: 45
                },
                {
                    _id: 4,
                    category: "Movies & Entertainment",
                    categoryClass: "movies",
                    formattedDate: "November 3, 2025",
                    formattedDuration: "3h 00m",
                    hours: 3,
                    minutes: 0
                },
                {
                    _id: 5,
                    category: "Study & Learning",
                    categoryClass: "study",
                    formattedDate: "November 2, 2025",
                    formattedDuration: "2h 30m",
                    hours: 2,
                    minutes: 30
                },
                {
                    _id: 6,
                    category: "Social Media",
                    categoryClass: "social-media",
                    formattedDate: "November 2, 2025",
                    formattedDuration: "1h 20m",
                    hours: 1,
                    minutes: 20
                }
            ]
        };

        res.render('sessions', sessionsData);
    }
}

module.exports = sessionsController;