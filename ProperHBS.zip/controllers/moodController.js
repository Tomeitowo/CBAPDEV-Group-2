const moodController = {
    getMood: async function(req, res) {
        // Sample mood data
        const moodData = {
            insights: [
                {
                    icon: "💡",
                    title: "Pattern Detected",
                    description: "You tend to feel better on days when your social media usage is under 1 hour. Your average mood on those days is 85% positive compared to 65% on high-usage days."
                },
                {
                    icon: "⚠️",
                    title: "Consider Taking Breaks",
                    description: "Your mood has been lower this week, coinciding with increased gaming sessions. Try incorporating more breaks or outdoor activities."
                },
                {
                    icon: "✨",
                    title: "Positive Trend",
                    description: "Great news! Your overall mood has improved by 20% over the past two weeks as you've been meeting your screen time goals consistently."
                }
            ],
            moods: [
                {
                    _id: "1",
                    emoji: "🙂",
                    label: "Good",
                    formattedDate: "November 4, 2025",
                    note: "Productive work day. Managed to stay within my screen time goals and felt energized throughout.",
                    totalScreenTime: "6h 45m",
                    goalsMetText: "✓ 2 of 3 goals met"
                },
                {
                    _id: "2",
                    emoji: "😐",
                    label: "Okay",
                    formattedDate: "November 3, 2025",
                    note: "Spent more time gaming than planned. Felt a bit sluggish by the evening.",
                    totalScreenTime: "8h 15m",
                    goalsMetText: "✓ 1 of 3 goals met"
                },
                {
                    _id: "3",
                    emoji: "😄",
                    label: "Excellent",
                    formattedDate: "November 2, 2025",
                    note: "Amazing day! Took regular breaks from screens and went for a walk. Completed all my goals.",
                    totalScreenTime: "5h 30m",
                    goalsMetText: "✓ 3 of 3 goals met"
                },
                {
                    _id: "4",
                    emoji: "😟",
                    label: "Down",
                    formattedDate: "November 1, 2025",
                    note: "Scrolled social media too much. Felt anxious and couldn't focus well.",
                    totalScreenTime: "9h 45m",
                    goalsMetText: "✓ 0 of 3 goals met"
                },
                {
                    _id: "5",
                    emoji: "🙂",
                    label: "Good",
                    formattedDate: "October 31, 2025",
                    note: "Balanced day. Worked on a project and relaxed with a movie in the evening.",
                    totalScreenTime: "7h 20m",
                    goalsMetText: "✓ 2 of 3 goals met"
                }
            ]
        };

        res.render('mood', moodData);
    },

    // Create new mood entry
    createMood: async function(req, res) {
        try {
            const { moodLevel, note } = req.body;

            // Validate required fields
            if (!moodLevel) {
                return res.status(400).json({ 
                    success: false, 
                    error: 'Mood level is required' 
                });
            }

            // Map mood level to emoji and label
            const moodMap = {
                'very-happy': { emoji: '😄', label: 'Excellent' },
                'happy': { emoji: '🙂', label: 'Good' },
                'neutral': { emoji: '😐', label: 'Okay' },
                'sad': { emoji: '😟', label: 'Down' },
                'very-sad': { emoji: '😢', label: 'Struggling' }
            };

            const moodData = moodMap[moodLevel];
            if (!moodData) {
                return res.status(400).json({ 
                    success: false, 
                    error: 'Invalid mood level' 
                });
            }

            // Generate new mood entry
            const newMood = {
                _id: Date.now().toString(),
                emoji: moodData.emoji,
                label: moodData.label,
                formattedDate: new Date().toLocaleDateString('en-US', {
                    weekday: 'long',
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric'
                }),
                note: note || 'No note added.',
                totalScreenTime: "0h 0m", // You can calculate this from actual data
                goalsMetText: "✓ New entry"
            };

            res.json({
                success: true,
                mood: newMood
            });

        } catch (error) {
            console.error('Error creating mood:', error);
            res.status(500).json({ 
                success: false, 
                error: 'Failed to create mood entry' 
            });
        }
    },

    // Update mood entry
    updateMood: async function(req, res) {
        try {
            const { id } = req.params;
            const { moodLevel, note } = req.body;

            // Map mood level to emoji and label
            const moodMap = {
                'very-happy': { emoji: '😄', label: 'Excellent' },
                'happy': { emoji: '🙂', label: 'Good' },
                'neutral': { emoji: '😐', label: 'Okay' },
                'sad': { emoji: '😟', label: 'Down' },
                'very-sad': { emoji: '😢', label: 'Struggling' }
            };

            const moodData = moodMap[moodLevel];
            if (!moodData) {
                return res.status(400).json({ 
                    success: false, 
                    error: 'Invalid mood level' 
                });
            }

            // In a real app, you'd update the database
            // For now, just return the updated data
            const updatedMood = {
                _id: id,
                emoji: moodData.emoji,
                label: moodData.label,
                note: note || 'No note added.',
                formattedDate: "Updated just now", // You might want to keep original date
                totalScreenTime: "6h 45m", // Keep original data
                goalsMetText: "✓ 2 of 3 goals met" // Keep original data
            };

            res.json({
                success: true,
                mood: updatedMood
            });

        } catch (error) {
            console.error('Error updating mood:', error);
            res.status(500).json({ 
                success: false, 
                error: 'Failed to update mood entry' 
            });
        }
    },

    // Delete mood entry
    deleteMood: async function(req, res) {
        try {
            const { id } = req.params;

            // In a real app, you'd delete from database
            // For now, just return success

            res.json({
                success: true,
                message: 'Mood entry deleted successfully'
            });

        } catch (error) {
            console.error('Error deleting mood:', error);
            res.status(500).json({ 
                success: false, 
                error: 'Failed to delete mood entry' 
            });
        }
    }
}

module.exports = moodController;