const insightsController = {
    getInsights: async function(req, res) {
        // Sample insights data
        const insightsData = {
            stats: {
                totalScreenTime: "48h 30m",
                totalChange: "+12% from last week",
                totalChangeClass: "positive",
                goalsAchieved: "8/12",
                goalsSuccessRate: "67% success rate",
                goalsChangeClass: "positive",
                averageMood: "Good",
                moodTrend: "Improving",
                moodChangeClass: "positive",
                dailyAverage: "6h 55m",
                avgChange: "-45m from last week",
                avgChangeClass: "positive"
            },
            goalProgress: [
                {
                    name: "Social Media Limit",
                    percentage: "75",
                    progressWidth: 75,
                    exceeded: false,
                    color: "#b794f6"
                },
                {
                    name: "Work Hours",
                    percentage: "90",
                    progressWidth: 90,
                    exceeded: false,
                    color: "#48bb78"
                },
                {
                    name: "Gaming Time",
                    percentage: "125",
                    progressWidth: 100,
                    exceeded: true,
                    color: "#667eea"
                },
                {
                    name: "Study Sessions",
                    percentage: "60",
                    progressWidth: 60,
                    exceeded: false,
                    color: "#4299e1"
                }
            ],
            summary: {
                mostUsedCategory: "Work-related",
                bestDay: "Wednesday",
                longestSession: "4h 30m (Work)",
                activeStreak: "12 days"
            },
            recommendations: [
                {
                    icon: "💡",
                    title: "Reduce Gaming Time",
                    description: "Your gaming sessions are exceeding your goals. Try setting a timer or taking regular breaks."
                },
                {
                    icon: "⏰",
                    title: "Morning Productivity",
                    description: "You're most productive before 2 PM. Schedule important work during these hours."
                },
                {
                    icon: "📱",
                    title: "Social Media Balance",
                    description: "Consider using app timers for social media to stay within your daily limits."
                },
                {
                    icon: "🎯",
                    title: "Study Consistency",
                    description: "Try to maintain consistent study sessions throughout the week rather than long weekend sessions."
                }
            ],
            chartDataJSON: JSON.stringify({
                trendData: [8.5, 7.2, 7.8, 9.7, 5.5, 8.3, 6.8],
                trendLabels: ['Oct 29', 'Oct 30', 'Oct 31', 'Nov 1', 'Nov 2', 'Nov 3', 'Nov 4'],
                categoryData: [45, 20, 15, 12, 8],
                categoryLabels: ['Work-related', 'Social Media', 'Movies', 'Gaming', 'Study'],
                moodCorrelationData: [
                    { x: 5.5, y: 5 },
                    { x: 6.8, y: 4 },
                    { x: 7.2, y: 4 },
                    { x: 7.8, y: 3 },
                    { x: 8.3, y: 3 },
                    { x: 8.5, y: 2 },
                    { x: 9.7, y: 2 }
                ]
            })
        };

        res.render('insights', insightsData);
    }
}

module.exports = insightsController;