const registerController = {
    getRegister: function (req, res) {
        res.render('register');  
    }
}

module.exports = registerController;