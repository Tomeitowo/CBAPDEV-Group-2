// import module 'express'
const express = require('express');

//import module 'hbs'
const hbs = require('hbs');

// import module 'routes' from './routes/routes.js'
const routes = require('./routes/routes.js');

/*
// import module 'database' from './model/db.js'
const db = require('./models/db.js');
*/

const app = express();
const port = 3000;

// set hbs as view engine
app.set('view engine', 'hbs');

app.use(express.static('public'));

app.use(express.urlencoded({extended: true}));

//define paths contained in 'routes'
app.use('/', routes);

// error handler for undefined routes
app.use(function (req, res) {
    res.render('error');
});

/*
// connects to the database
db.connect();
*/

app.listen(port, function () {
    console.log('app listening at port ' + port);
});